import React from 'react'




const Page2 = () => (

  
    <div>
      <h1>Refresh Market</h1>

      <>
        <button>Generate new</button>
      </>
    </div>
  )

export default Page2
